![GitHub Created At](https://img.shields.io/github/created-at/bardurt/odontograma?style=plastic)
![GitHub Stars](https://img.shields.io/github/stars/bardurt/odontograma?style=plastic)
![GitHub Forks](https://img.shields.io/github/forks/bardurt/odontograma?style=plastic)
![GitHub License](https://img.shields.io/github/license/bardurt/odontograma?style=plastic)

# Odontograph
A virtual Odontogram in JavaScript.

![demo](docs/demo.gif)
